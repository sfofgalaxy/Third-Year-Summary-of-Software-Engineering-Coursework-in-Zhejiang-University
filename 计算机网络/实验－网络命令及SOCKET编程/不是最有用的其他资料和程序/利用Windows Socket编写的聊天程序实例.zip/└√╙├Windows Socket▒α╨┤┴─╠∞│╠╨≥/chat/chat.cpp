/****************************************************************************
					     chat source code
		A simple chat application which can be either server or client.When 
	working as a server user can specify the port number for listening.User
	can use Ctrl+Enter to send message.
		The programme is implemented with asyncsocket I/O model which is 
	message-based.The project consist of two files--chat.cpp(mainly about window
	management) and net.h(socket code).
		This programme is written with Win32 API and C style.
		Author: binix@88.zju      Nov. 2004
 ****************************************************************************/

#include <stdlib.h>
#include "resource.h"
#include <winsock2.h>
#include <richedit.h>

//must big enough to display text
#define BUFSIZE (1024*64)

HINSTANCE hInst;
HWND hWnd,hOWnd,hIWnd,hIPEdit,hPortEdit,hConnBtn,hListenBtn;
//this buffer is used frequently for both text ouput and socket send/recv
TCHAR buf[BUFSIZE];
//cur:the current start position of empty buf
//sendpos:the start position of the data to be sent
int cur=0,sendpos=0;
//used to indicat current status
BOOL conned=FALSE,listening=FALSE;

void Input();
void ClearBuf();
void PrintLastError();
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

#include "net.h"

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
	hInst = hInstance;
	//register window class
	WNDCLASSEX wcex;
	wcex.cbSize			= sizeof(WNDCLASSEX);
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= NULL;
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_BTNFACE+1);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= "CHAT";
	wcex.hIconSm		= NULL;
	RegisterClassEx(&wcex);
	//create main window
	hWnd = CreateWindow("CHAT", "Chat", WS_OVERLAPPEDWINDOW &~ WS_MAXIMIZEBOX &~ WS_THICKFRAME, 200, 200, 505, 410, NULL, NULL, hInstance, NULL);
	if (!hWnd)
	{
		return FALSE;
	}
	//display window
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	//initiate socket
	if(!NetInit()) return 0;
	//message loop
	MSG msg;
	HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_ACCEL));
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		//check for accelerator
		if(!TranslateAccelerator(hWnd,hAccelTable,&msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
	//close socket
	NetEnd();
	return msg.wParam;
}

//main window message processing function
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	HFONT hfont;
	switch (message) 
	{
		case WM_SOCKET:
			//socket message is sent to ProcessSocketMsg defined in net.h
			ProcessSocketMsg(wParam,lParam);
			break;
		case WM_CREATE:
			//when main window has been created,just create controls
			LoadLibrary("RICHED20.DLL");
			hOWnd=CreateWindowEx(WS_EX_CLIENTEDGE,RICHEDIT_CLASS,NULL,WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_LEFT|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY,10,10,350,250,hWnd,NULL,hInst,NULL);
			hIWnd=CreateWindowEx(WS_EX_CLIENTEDGE,RICHEDIT_CLASS,NULL,WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_LEFT|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY,10,270,350,100,hWnd,NULL,hInst,NULL);
			hIPEdit=CreateWindowEx(WS_EX_CLIENTEDGE,"EDIT","127.0.0.1",WS_CHILD|WS_VISIBLE|ES_LEFT|ES_AUTOHSCROLL,370,10,120,25,hWnd,(HMENU)ID_IPEDIT,hInst,NULL);
			hPortEdit=CreateWindowEx(WS_EX_CLIENTEDGE,"EDIT","8888",WS_CHILD|WS_VISIBLE|ES_LEFT|ES_NUMBER,370,45,50,25,hWnd,(HMENU)ID_PORTEDIT,hInst,NULL);
			hConnBtn=CreateWindowEx(0,"BUTTON","Connect",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|BS_DEFPUSHBUTTON,370,80,100,25,hWnd,(HMENU)ID_CONNBTN,hInst,NULL);
			hListenBtn=CreateWindowEx(0,"BUTTON","Listen",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|BS_DEFPUSHBUTTON,370,115,100,25,hWnd,(HMENU)ID_LISTENBTN,hInst,NULL);
			//set font
			LOGFONT lf;
			lf.lfCharSet=DEFAULT_CHARSET;
			lf.lfClipPrecision=CLIP_DEFAULT_PRECIS;
			lf.lfEscapement=0;
			strcpy(lf.lfFaceName,"Verdana");
			lf.lfHeight=15;
			lf.lfItalic=FALSE;
			lf.lfOrientation=0;
			lf.lfOutPrecision=OUT_DEFAULT_PRECIS;
			lf.lfPitchAndFamily=FF_MODERN|DEFAULT_PITCH;
			lf.lfQuality=DEFAULT_QUALITY;
			lf.lfStrikeOut=FALSE;
			lf.lfUnderline=FALSE;
			lf.lfWeight=FW_BOLD;
			lf.lfWidth=7;
			hfont=CreateFontIndirect(&lf);
			SendMessage(hOWnd,WM_SETFONT,(WPARAM)hfont,MAKELPARAM(FALSE,0));
			SendMessage(hIWnd,WM_SETFONT,(WPARAM)hfont,MAKELPARAM(FALSE,0));
			SendMessage(hIPEdit,WM_SETFONT,(WPARAM)hfont,MAKELPARAM(FALSE,0));
			SendMessage(hPortEdit,WM_SETFONT,(WPARAM)hfont,MAKELPARAM(FALSE,0));
			SendMessage(hConnBtn,WM_SETFONT,(WPARAM)hfont,MAKELPARAM(FALSE,0));
			break; 
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam);
			switch(wmId)
			{
			case IDM_INPUT: Input();break;//when user press ctrl+enter
			case ID_CONNBTN://connect button is clicked
				if(conned)
				//if connection has been created,the command means to close the connection
				{
					NetDisconn();
					SendMessage(hConnBtn,WM_SETTEXT,0,(long)"Connect");
					EnableWindow(hIPEdit,TRUE);
					EnableWindow(hPortEdit,TRUE);
					EnableWindow(hListenBtn,TRUE);
					SendMessage(hIWnd,EM_SETREADONLY,TRUE,0);
					conned=FALSE;
				}
				else
				//user want to connect to remote
				{
					char ipstr[1024],portstr[16];
					SendMessage(hIPEdit, WM_GETTEXT, 1024, (long)ipstr);
					SendMessage(hPortEdit, WM_GETTEXT, 16, (long)portstr);
					//connect
					if(NetConn(ipstr,atoi(portstr)))
					{
						EnableWindow(hConnBtn,FALSE);
						EnableWindow(hIPEdit,FALSE);
						EnableWindow(hPortEdit,FALSE);
						EnableWindow(hListenBtn,FALSE);
					}
				}
				break;
			case ID_LISTENBTN://listen button is clicked
				if(listening)
				{//means to cancel listening
					closesocket(tcps_listen);
					EnableWindow(hIPEdit,TRUE);
					EnableWindow(hPortEdit,TRUE);
					EnableWindow(hConnBtn,TRUE);
					SendMessage(hListenBtn,WM_SETTEXT,0,(long)"Listen");
					listening=FALSE;
				}
				else
				{
					char portstr[16];
					SendMessage(hPortEdit, WM_GETTEXT, 16, (long)portstr);
					//listen
					if(NetListen(atoi(portstr)))
					{
						EnableWindow(hConnBtn,FALSE);
						EnableWindow(hIPEdit,FALSE);
						EnableWindow(hPortEdit,FALSE);
					}
				}
				break;
			}
			break;
		case WM_PAINT:
			//repaint windows
			hdc = BeginPaint(hWnd, &ps);
			RECT rt;
			GetClientRect(hWnd, &rt);
			EndPaint(hWnd, &ps);
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

//clear the buffer,clear the content of the richedit
void ClearBuf()
{
	SendMessage(hOWnd,WM_SETTEXT,0,NULL);
	memset(buf,0,BUFSIZE);
	cur=0;
}

//send the input of user and display it in the richedit control
inline void Input()
{
	sendpos=cur;
	if(cur+SendMessage(hIWnd,WM_GETTEXTLENGTH,0,0)+1>=BUFSIZE) ClearBuf();
	cur+=SendMessage(hIWnd,WM_GETTEXT,BUFSIZE-cur-1,long(buf+cur));
	//add a newline char to the end of text
	buf[cur++]='\n';
	if(NetSend())
	{
		SendMessage(hOWnd,WM_SETTEXT,0,(long)buf);
		SendMessage(hIWnd,WM_SETTEXT,0,NULL);
	}
}

//used to ouput error text
void PrintLastError()
{
	LPVOID lpMsgBuf;
	FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
					NULL,
					GetLastError(),
					MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
					(LPTSTR) &lpMsgBuf,
					0,
					NULL );
	MessageBox( NULL, (LPCTSTR)lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION );
	LocalFree( lpMsgBuf );
}