#define WM_SOCKET (WM_USER+1)

SOCKET tcps,tcps_listen;
BOOL beSendBlock=FALSE;

inline int NetInit()
{
	WORD wVersionRequested;
	WSADATA wsaData;
	int err;
	wVersionRequested = MAKEWORD( 1, 1 );
	err = WSAStartup( wVersionRequested, &wsaData );
	if ( err != 0 )
	{
		MessageBox(NULL,"Winsock startup error!","Error",0);
		return 0;
	}
	if ( LOBYTE( wsaData.wVersion ) != 1 || HIBYTE( wsaData.wVersion ) != 1 )
	{
		WSACleanup();
		MessageBox(NULL,"Invalid winsock version!","Error",0);
		return 0;
	}
	return 1;
}

inline void NetEnd()
{
	closesocket(tcps);
	WSACleanup();
}

inline int NetListen(int port)
{
	ClearBuf();
	tcps_listen=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(tcps==INVALID_SOCKET)
	{
		MessageBox(NULL,"Can't create socket!","Error",0);
		return 0;
	}
	if(SOCKET_ERROR==WSAAsyncSelect(tcps_listen,hWnd,WM_SOCKET,FD_ACCEPT|FD_READ|FD_WRITE|FD_CLOSE))
	{
		MessageBox(NULL,"Select error!","Error",0);
		return 0;
	}
	SOCKADDR_IN tcpaddr;
	tcpaddr.sin_family=AF_INET;
	tcpaddr.sin_port=htons(port);
	tcpaddr.sin_addr.S_un.S_addr=htonl(INADDR_ANY);
	int err=bind(tcps_listen,(SOCKADDR*)&tcpaddr,sizeof(tcpaddr));
	if (err!=0)
	{
		MessageBox(NULL,"Bind error!","Error",0);
		return 0;
	}
	err=listen(tcps_listen,1);
	if (err!=0)
	{
		MessageBox(NULL,"Listen error!","Error",0);
		return 0;
	}
	SendMessage(hListenBtn,WM_SETTEXT,0,(long)"Cancel");
	listening=TRUE;
	return 1;
}

inline int NetConn(LPCSTR ipstr,int port)
{
	ClearBuf();
	tcps=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(tcps==INVALID_SOCKET)
	{
		MessageBox(NULL,"Can't create socket!","Error",0);
		return 0;
	}
	if(SOCKET_ERROR==WSAAsyncSelect(tcps,hWnd,WM_SOCKET,FD_CONNECT|FD_READ|FD_WRITE|FD_CLOSE))
	{
		MessageBox(NULL,"Select error!","Error",0);
		return 0;
	}
	unsigned long ip=inet_addr(ipstr);
	if(INADDR_NONE==ip)
	{
		hostent * he=gethostbyname(ipstr);
		ip=*((unsigned long *)(he->h_addr_list[0]));
	}
	struct sockaddr_in addr;
	addr.sin_family=AF_INET;
	addr.sin_addr.S_un.S_addr=ip;
	addr.sin_port=htons(port);
	if(SOCKET_ERROR==connect(tcps,(sockaddr*)&addr,sizeof(addr)))
	{
		if(WSAGetLastError()!=WSAEWOULDBLOCK)
		{
			MessageBox(hWnd,"Error when connect!","Error",0);
			return 0;
		}
	}
	return 1;
}

inline void NetDisconn()
{
	closesocket(tcps);
}

inline int NetSend()
{
	if(beSendBlock) return 0;
	while(sendpos<cur)
	{
		int rs=send(tcps,buf+sendpos,cur-sendpos,0);
		if(SOCKET_ERROR==rs)
		{
			if(WSAEWOULDBLOCK==WSAGetLastError())
			{
				beSendBlock=TRUE;
				SendMessage(hIWnd,EM_SETREADONLY,TRUE,0);
				return 0;
			}
		}
		else
		{
			sendpos+=rs;
		}
	}
	return 1;
}

inline void ProcessSocketMsg(WPARAM wParam, LPARAM lParam)
{
	if(WSAGETSELECTERROR(lParam))
	{
		switch(WSAGETSELECTERROR(lParam))
		{
		case WSAETIMEDOUT: MessageBox(hWnd,"Connect timeout!","Error",0);break;
		default: MessageBox(hWnd,"Some error occurs!","Error",0);break;
		}
		NetDisconn();
		SendMessage(hConnBtn,WM_SETTEXT,0,(long)"Connect");
		EnableWindow(hIPEdit,TRUE);
		EnableWindow(hPortEdit,TRUE);
		EnableWindow(hConnBtn,TRUE);
		EnableWindow(hListenBtn,TRUE);
		conned=FALSE;
		listening=FALSE;
		return;
	}
	else
	{
		switch(WSAGETSELECTEVENT(lParam))
		{
		case FD_ACCEPT:
			tcps=accept(tcps_listen,NULL,NULL);
			closesocket(tcps_listen);
			SendMessage(hConnBtn,WM_SETTEXT,0,(long)"Disconnect");
			SendMessage(hListenBtn,WM_SETTEXT,0,(long)"Listen");
			SendMessage(hIWnd,EM_SETREADONLY,FALSE,0);
			EnableWindow(hListenBtn,FALSE);
			EnableWindow(hConnBtn,TRUE);
			listening=FALSE;
			conned=TRUE;
			break;
		case FD_CONNECT:
			SendMessage(hConnBtn,WM_SETTEXT,0,(long)"Disconnect");
			EnableWindow(hConnBtn,TRUE);
			SendMessage(hIWnd,EM_SETREADONLY,FALSE,0);
			conned=TRUE;
			break;
		case FD_CLOSE:
			MessageBox(hWnd,"Remote close the connection!","OK",0);
			NetDisconn();
			SendMessage(hConnBtn,WM_SETTEXT,0,(long)"Connect");
			EnableWindow(hIPEdit,TRUE);
			EnableWindow(hPortEdit,TRUE);
			EnableWindow(hListenBtn,TRUE);
			SendMessage(hIWnd,EM_SETREADONLY,TRUE,0);
			conned=FALSE;
			break;
		case FD_READ:
			if(cur>=BUFSIZE-1) ClearBuf();
			cur+=recv(tcps,buf+cur,BUFSIZE-cur-1,0);
			SendMessage(hOWnd,WM_SETTEXT,0,(long)buf);
			break;
		case FD_WRITE:
			if(beSendBlock)
			{
				beSendBlock=FALSE;
				if(NetSend())
				{
					SendMessage(hOWnd,WM_SETTEXT,0,(long)buf);
					SendMessage(hIWnd,WM_SETTEXT,0,NULL);
					SendMessage(hIWnd,EM_SETREADONLY,FALSE,0);
				}
			}
			break;
		}
	}
}